<template>
  <div class="sports">
    <h2 class="sports-title">Odvetvia bojových športov</h2>
    <div class="sports-list">
      <div v-for="sport in sports" :key="sport.id" class="sport-item">
        <h3 @click="toggleDetails(sport.id)">{{ sport.name }}</h3>
        <p>{{ sport.description }}</p>

        <!-- Zobraziť detaily iba ak je rozkliknuté -->
        <div v-if="activeSportId === sport.id" class="sport-details">
          <p><strong>História:</strong> {{ sport.history }}</p>
          <p><strong>Technika:</strong> {{ sport.techniques }}</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Linky vedľa seba -->
  <div class="links-wrapper">
    <router-link to="/box" class="link-button">Viac o Boxe</router-link>
    <router-link to="/mma" class="link-button">Viac o MMA</router-link>
    <router-link to="/kickbox" class="link-button">Viac o Kickboxe</router-link>
    <router-link to="/muaythai" class="link-button">Viac o Muay Thai</router-link>
    <router-link to="/kravmaga" class="link-button">Viac o Krav Mage</router-link>
  </div>

  <!-- Sekcia s obrázkom zápasníka -->
  <div class="fighter-profile">
    <div class="fighter-image">
      <img src="@/assets/mike_tyson.jpg" alt="Jmike" />
    </div>
    <div class="fighter-text">
      <h2>"Iron" Mike Tyson</h2>
      <p>
        Mike Tyson, celým menom Michael Gerard Tyson, je bývalý americký profesionálny boxer,
        ktorý sa považuje za jedného z najdominantnejších a najkontroverznejších športovcov v
        histórii boxu. Narodil sa 30. júna 1966 v Brooklyne v New Yorku. Už vo veku 20 rokov
        sa stal najmladším majstrom sveta v ťažkej váhe, keď v roku 1986 získal titul WBC po výhre
        nad Trevorom Berbickom.<br><br>
        Tyson bol známy svojou agresívnou bojovou technikou, neuveriteľnou silou a schopnosťou knokautovať
        súperov už v prvých kolách. Jeho kariéru však sprevádzali aj škandály, právne problémy a osobné výzvy,
        vrátane odsúdenia za znásilnenie a neskorších finančných problémov. Napriek tomu sa stal ikonou
        popkultúry a po ukončení kariéry sa venoval herectvu, podcastom a podnikaniu. Dodnes zostáva
        legendou svetového boxu.
      </p>
    </div>
  </div>



  <!-- Sekcia s obrázkom zápasníka -->
  <div class="fighter-profile">
    <div class="fighter-image">
      <img src="@/assets/conor_mcgregor.jpg" alt="Jiří Procházka" />
    </div>
    <div class="fighter-text">
      <h2>Conor McGregor</h2>
      <p>
        Conor McGregor je írsky MMA bojovník a bývalý šampión UFC v perovej a ľahkej váhe,
        známy svojím agresívnym štýlom a charizmou. Narodil sa 14. júla 1988 v Dubline.
        Stal sa prvým bojovníkom UFC, ktorý držal tituly v dvoch váhových kategóriách naraz.
        Okrem športu sa venuje podnikaniu, vrátane značky whiskey Proper No. Twelve, a je
        jednou z najväčších hviezd MMA histórie.
      </p>
    </div>
  </div>

  <!-- Sekcia s obrázkom zápasníka -->
  <div class="fighter-profile">
    <div class="fighter-image">
      <img src="@/assets/rico_verhoeven.jpg" alt="rico" />
    </div>
    <div class="fighter-text">
      <h2>Rico Verhoeven</h2>
      <p>
        Rico Verhoeven je holandský kickboxer, známy svojou dominanciou v ťažkej váhe organizácie Glory.
        Narodený 10. apríla 1989, Verhoeven je uznávaný pre svoju technickú precíznosť, fyzickú silu a
        neuveriteľnú kondíciu, ktorá mu umožňuje obhajovať tituly proti najlepším bojovníkom sveta.
      </p>
      <p>
        Počas svojej kariéry získal množstvo prestížnych titulov a je považovaný za jedného z
        najlepších kickboxerov všetkých čias. Rico je nielen bojovníkom, ale aj inšpiráciou
        pre mladé generácie, keďže svojimi hodnotami a pracovnou morálkou dokazuje, že s odhodlaním
        je možné dosiahnuť čokoľvek.
      </p>
    </div>
  </div>

  <!-- Sekcia s obrázkom zápasníka -->
  <div class="fighter-profile">
    <div class="fighter-image">
      <img src="@/assets/saenchai.jpg" alt="Saenchai" />
    </div>
    <div class="fighter-text">
      <h2>Saenchai</h2>
      <p>
        Saenchai (vlastným menom Parinya Charoenphol) je thajský Muay Thai bojovník, považovaný
        za jedného z najlepších a najikonickejších v histórii tohto športu. Narodil sa 30. júla 1980 v Thajsku.
        Saenchai je známy svojou technickou brilantnosťou, vynikajúcimi reflexmi a schopnosťou prispôsobiť
        sa rôznym štýlom boja. Je obľúbený pre svoju schopnosť robiť nevídané údery a kombinácie, ako aj
        pre svoju flexibilitu a kreativitu v ringu. V priebehu svojej kariéry získal množstvo titulov,
        vrátane majstra sveta v niekoľkých váhových kategóriách. Okrem toho je často považovaný za jeden
        z najzábavnejších bojovníkov, ktorého zápasy sú naplnené technickou krásou a dynamikou.
      </p>
    </div>
  </div>

  <!-- Sekcia s obrázkom zápasníka -->
  <div class="fighter-profile">
    <div class="fighter-image">
      <img src="@/assets/imi_lichtenfeld.jpeg" alt="Imi-Lichtenfeld" />
    </div>
    <div class="fighter-text">
      <h2>Imi Lichtenfeld</h2>
      <p>
        Imi Lichtenfeld (1910–1998) bol slovenský židovský pôvodom, zakladateľ systému sebaobrany
        známeho ako Krav Maga. Narodil sa v Bratislave a vyštudoval vojenskú školu. Počas druhej
        svetovej vojny sa stal členom židovskej obrany v Bratislave, kde vyvinul techniky boja,
        ktoré neskôr skombinoval do efektívneho systému sebaobrany. Po vojne sa presťahoval do Izraela,
        kde Krav Maga získala vojenské a civilné využitie. Tento systém sa vyznačuje jednoduchosťou,
        rýchlosťou a účinnosťou, a dnes je používaný v armádach a policajných jednotkách po celom svete.
        Lichtenfeld bol považovaný za vynikajúceho učiteľa a odborníka v oblasti boja a sebaobrany.
      </p>
    </div>
  </div>
</template>

<script>
import { useSportsStore } from "../stores/sports";
import { ref } from "vue";

export default {
  name: "Sports",
  setup() {
    const sportsStore = useSportsStore();

    // Premenná na ukladanie aktívneho športu
    const activeSportId = ref(null);

    // Funkcia na rozkliknutie športu
    const toggleDetails = (id) => {
      // Ak už je šport aktívny, zavrie sa, inak sa otvorí
      activeSportId.value = activeSportId.value === id ? null : id;
    };

    return {
      sports: sportsStore.sports,
      activeSportId,
      toggleDetails,
    };
  },
};
</script>

<style scoped>
.links-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px; /* Priestor medzi tlačidlami */
  background-color: #282828; /* Rovnaké pozadie ako zvyšok stránky */
  padding: 20px; /* Padding pre väčší priestor okolo tlačidiel */
}

.link-button {
  padding: 10px 20px;
  background-color: #f1c40f;
  color: #282828;
  text-decoration: none;
  border-radius: 5px;
  font-size: 1.2em;
  transition: background-color 0.3s ease; /* Plynulý prechod pre hover */
}

.link-button:hover {
  background-color: #f39c12;
}


.link-button {
  padding: 10px 20px;
  background-color: #f1c40f;
  color: #282828;
  text-decoration: none;
  border-radius: 5px;
  font-size: 1.2em;
  transition: background-color 0.3s ease; /* Plynulý prechod pre hover */
}

.link-button:hover {
  background-color: #f39c12;
}


.sports {
  padding: 40px 20px;
  background-color: #282828;
  text-align: center;
  color: white;
}

.sports-title {
  font-size: 2.5em;
  color: #f1c40f;
  margin-bottom: 30px;
}

.sports-list {
  display: flex;
  justify-content: center;
  gap: 40px;
  flex-wrap: wrap;
  overflow-x: hidden;
}

.sport-item {
  background-color: #3b3b3b;
  padding: 25px;
  width: 250px;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
  transition: all 0.3s ease;
  border: 3px solid #f1c40f;
  margin-bottom: 20px;
}

.sport-item h3 {
  font-size: 1.8em;
  color: #f1c40f;
  margin-bottom: 15px;
  cursor: pointer; /* Indikácia, že je to klikateľné */
}

.sport-item p {
  font-size: 1.1em;
  color: #bdc3c7;
  line-height: 1.6;
}

.sport-item:hover {
  background-color: #444444;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5);
  transform: scale(1.05);
}

.sport-details {
  margin-top: 15px;
  font-size: 1.1em;
  color: #ecf0f1;
  line-height: 1.6;
  text-align: left;
}

.sport-details p {
  margin-bottom: 10px;
}

@media (max-width: 1024px) {
  .sports-list {
    justify-content: center;
  }
}

@media (max-width: 768px) {
  .sports-list {
    justify-content: center;
    gap: 20px;
  }

  .sport-item {
    width: 200px;
  }
}
</style>
