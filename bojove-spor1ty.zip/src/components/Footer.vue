<template>
  <footer>
    <p>&copy; 2024 Bojové športy. Všetky práva vyhradené.</p>
  </footer>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
footer {
  text-align: center;
  padding: 10px;
  background-color: #f5f5f5;
  margin-top: 20px;
}
</style>
