// stores/sportsStore.js
import { defineStore } from 'pinia';

export const useSportsStore = defineStore('sports', {
  state: () => ({
    sports: [
      {
        id: 1,
        name: "Box",
        description: "Tradičný šport so silnými údermi.",
        history: "Box má svoje korene v starovekom Grécku a Ríme. Dnes je jedným z najpopulárnejších bojových športov na svete.",
        techniques: "Základné techniky zahŕňajú údery päsťami, úhyby, kryt a protiútoky.",
        image: "box.jpg",  // cesta k obrázku
        isOpen: false,
        bestFighter: {
          name: "Mike Tyson",
          bio: "Mike Tyson je považovaný za jedného z najväčších boxerov všetkých čias.",
          image: "mike_tyson.jpg"  // cesta k obrázku
        }
      },
      {
        id: 2,
        name: "MMA",
        description: "Zmiešané bojové umenia pre všestranných bojovníkov.",
        history: "MMA vzniklo v 90. rokoch v USA a je to jeden z najmodernejších športov.",
        techniques: "V MMA sa kombinuje techniky z rôznych bojových umení.",
        image: "mma.jpg",  // cesta k obrázku
        isOpen: false,
        bestFighter: {
          name: "Conor McGregor",
          bio: "Conor McGregor je jedným z najznámejších MMA bojovníkov.",
          image: "conor_mcgregor.jpg"  // cesta k obrázku
        }
      },
      {
        id: 3,
        name: "Kickbox",
        description: "Bojový šport kombinujúci kopy a údery.",
        history: "Kickbox sa vyvinul v 60. rokoch v USA a Japonku ako kombinácia tradičných zápasníckych techník a thajského boxu.",
        techniques: "Techniky zahŕňajú údery rukami, kopmi, kolenami a niekedy aj lakťami.",
        image: "kickbox.jpg",  // cesta k obrázku
        isOpen: false,
        bestFighter: {
          name: "Rico Verhoeven",
          bio: "Rico Verhoeven je známy ako 'Král kickboxu'.",
          image: "rico_verhoeven.jpg"  // cesta k obrázku
        }
      },
      {
        id: 4,
        name: "Muay Thai",
        description: "Bojový šport kombinujúci kopy, ľakte a kolená.",
        history: "Muay Thai pochádza z Thajska a je známy ako 'umění ôsmich končatín'. Je to veľmi účinný a agresívny bojový šport.",
        techniques: "Techniky zahŕňajú kopy, údery päsťami, lakťami, kolenami a klinčovanie.",
        image: "muay_thai.jpg",  // cesta k obrázku
        isOpen: false,
        bestFighter: {
          name: "Saenchai",
          bio: "Saenchai je legendárny thajský bojovník v Muay Thai.",
          image: "saenchai.jpg"  // cesta k obrázku
        }
      },
      {
        id: 5,
        name: "Krav Maga",
        description: "Bojové umenie zamerané na sebeobranu.",
        history: "Krav Maga bola vyvinutá v Izraeli ako praktický systém pre sebaobranu a boj v reálnych situáciách.",
        techniques: "Krav Maga sa zameriava na jednoduché, efektívne techniky zamerané na neutralizáciu hrozieb a útoky.",
        image: "krav_maga.jpg",  // cesta k obrázku
        isOpen: false,
        bestFighter: {
          name: "Imi Lichtenfeld",
          bio: "Imi Lichtenfeld je zakladateľom Krav Magy.",
          image: "imi_lichtenfeld.jpg"  // cesta k obrázku
        }
      },
    ],
  }),
  actions: {
    toggleDetails(id) {
      const sport = this.sports.find(sport => sport.id === id);
      if (sport) {
        sport.isOpen = !sport.isOpen;
      }
    }
  },
});
