<template>
  <div id="app">
    <!-- Navigačný panel -->
    <Header />

    <!-- Výstup aktuálnej stránky -->
    <router-view />

    <!-- Footer -->
    <Footer />
  </div>
</template>

<script>
import { createRouter, createWebHistory } from "vue-router";
import Sports from "./components/SportCategory.vue";
import Blog from "./components/BlogPost.vue";
import Timer from "./components/Timer.vue";
import Footer from "./components/Footer.vue"; // Import Footer
import Header from "./components/Header.vue"; // Import Header

const routes = [
  { path: "/", component: Sports },
  { path: "/sports", component: Sports },
  { path: "/blog", component: Blog },
  { path: "/timer", component: Timer },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default {
  name: "App",
  components: {
    Footer,
    Header, // Registrácia Header komponentu
  },
};
</script>

<style>
/* Footer */
.footer {
  background-color: #282828;
  color: #bdc3c7;
  padding: 20px 0;
  text-align: center;
  border-top: 3px solid #f1c40f;
}

.footer-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

.footer-links {
  display: flex;
  justify-content: center;
  gap: 15px;
  margin-bottom: 10px;
}

.footer-link {
  color: #f1c40f;
  text-decoration: none;
  font-weight: bold;
  font-size: 1em;
  transition: color 0.3s;
}

.footer-link:hover {
  color: #f39c12;
}

.footer-text {
  font-size: 0.9em;
  color: #bdc3c7;
}
</style>
