<template>
  <div class="whole">
    <div class="blog-post-page" v-if="postTitle">
      <div class="post-container">
        <header class="post-header">
          <h1 class="post-title">{{ postTitle }}</h1>
          <p class="post-date">Zverejnené: {{ postDate }}</p>
        </header>
        <div class="post-content" v-html="postContent"></div>
        <footer class="post-footer">
          <p class="post-author">
            Autor: <span>{{ postAuthor }}</span>
          </p>
        </footer>
      </div>
    </div>
    <div v-else>
      <p class="loading-message">Načítavam obsah...</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "BlogPostPage",
  props: {
    id: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      postTitle: "",
      postContent: "",
      postDate: "",
      postAuthor: "John Doe", // Príklad autora
    };
  },
  created() {
    this.loadPostData();
  },
  methods: {
    loadPostData() {
      if (this.id === "1") {
        this.postTitle = "Začíname s bojovými športami";
        this.postDate = "2. december 2024";
        this.postContent = `
          <p><b>Prečo si vybrať bojové športy?</b></p>výhod:</p>
          <ul>
          <p>Bojové športy ponúkajú široké spektrum
            <li><b>Fyzická kondícia:</b> Tréning zlepší vašu silu, vytrvalosť a ohybnosť.</li>
            <li><b>Sebavedomie:</b> Naučíte sa sebaobranu a zlepšíte svoje zručnosti.</li>
            <li><b>Disciplinovanosť:</b> Pravidelné tréningy a rešpekt k pravidlám vás naučia sebaovládaniu.</li>
            <li><b>Mentálna sila:</b> Zvládanie náročných situácií počas tréningu posilní vašu odolnosť.</li>
          </ul>
        `;
      } else if (this.id === "2") {
        this.postTitle = "Organizácie bojových športov";
        this.postDate = "15. november 2024";
        this.postContent = `
          <h1>Začiatky s bojovými športmi</h1>
          <p><strong>Bojové športy sú nielen fascinujúce na pohľad, ale aj skvelým spôsobom, ako zlepšiť fyzickú kondíciu,
          mentálnu silu a celkovú disciplínu. Ak zvažujete začať, tento článok vás prevedie prvými krokmi.</strong></p>
          <h2>Prečo si vybrať bojové športy?</h2>
          <p>Bojové športy ponúkajú široké spektrum výhod:</p>
          <ul>
            <li><strong>Fyzická kondícia</strong>: Tréning zlepší vašu silu, vytrvalosť a ohybnosť.</li>
            <li><strong>Sebavedomie</strong>: Naučíte sa sebaobranu a zlepšíte svoje zručnosti.</li>
            <li><strong>Disciplinovanosť</strong>: Pravidelné tréningy a rešpekt k pravidlám vás naučia sebaovládaniu.</li>
            <li><strong>Mentálna sila</strong>: Zvládanie náročných situácií počas tréningu posilní vašu odolnosť.</li>
          </ul>
          <h2>Ktorý bojový šport si vybrať?</h2>
          <p>Pri výbere športu je dôležité zvážiť svoje záujmy a ciele. Tu sú niektoré populárne možnosti:</p>
          <ul>
            <li><strong>Box</strong>: Skvelý na zlepšenie úderových techník, rýchlosti a výdrže.</li>
            <li><strong>Kickbox alebo Muay Thai</strong>: Kombinácia úderov a kopov, výborné na všestranný tréning.</li>
            <li><strong>Jiu-Jitsu alebo Judo</strong>: Zamerané na grappling, techniky znehybnenia a páky.</li>
            <li><strong>MMA (Mixed Martial Arts)</strong>: Kombinuje viacero bojových štýlov, ideálne pre tých, čo chcú komplexný tréning.</li>
            <li><strong>Karate alebo Taekwondo</strong>: Zamerané na techniku, disciplínu a flexibilitu.</li>
          </ul>
        `;
      }
    },
  },
};
</script>

<style scoped>
.whole {
  background-color: #282828;
}

.blog-post-page {
  display: flex;
  justify-content: center;
  padding: 20px;
}

.post-container {
  max-width: 800px;
  width: 100%;
  background-color: #ffffff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.post-header {
  text-align: center;
  margin-bottom: 20px;
}

.post-title {
  font-size: 2.5rem;
  color: #333333;
}

.post-date {
  color: #777777;
  font-size: 1.1rem;
}

.post-content {
  font-size: 1.1rem;
  line-height: 1.6;
  color: #555555;
}

.post-footer {
  margin-top: 20px;
  text-align: center;
}

.post-author {
  font-size: 1.2rem;
  color: #333333;
}

@media (max-width: 768px) {
  .post-title {
    font-size: 2rem;
  }

  .post-content {
    font-size: 1rem;
  }
}
</style>
