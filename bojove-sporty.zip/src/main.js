import { createApp } from "vue";
import App from "./App.vue";
import { createPinia } from "pinia"; // Import Pinia
import router from "./router";

const app = createApp(App);

app.use(createPinia()); // Používanie Pinia
app.use(router); // Používanie Vue Router
app.mount("#app");
