<script>
export default {
  name: 'SportCategory'
}
</script>

<template>

</template>

<style scoped>

</style>
