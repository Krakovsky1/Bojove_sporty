<template>
  <div class="timer">
    <div class="timer-display">
      <h3>{{ timeLeftFormatted }}</h3>
    </div>
    <div class="timer-controls">
      <button @click="startTimer" :disabled="isRunning">Štart</button>
      <button @click="stopTimer" :disabled="!isRunning">Zastaviť</button>
    </div>
  </div>
</template>

<script>
export default {
  name: "Timer",
  props: {
    duration: {
      type: Number,
      required: true,
    },
  },
  data() {
    return {
      timeLeft: this.duration, // Počiatočný čas (v sekundách)
      timerInterval: null,
      isRunning: false,
    };
  },
  computed: {
    timeLeftFormatted() {
      const minutes = Math.floor(this.timeLeft / 60);
      const seconds = this.timeLeft % 60;
      return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
    },
  },
  methods: {
    startTimer() {
      if (this.isRunning) return;
      this.isRunning = true;
      this.timerInterval = setInterval(() => {
        if (this.timeLeft > 0) {
          this.timeLeft--;
        } else {
          this.stopTimer();
        }
      }, 1000); // Odpočítava sekundy každú sekundu
    },
    stopTimer() {
      clearInterval(this.timerInterval);
      this.isRunning = false;
    },
  },
  watch: {
    duration(newValue) {
      // Ak sa zmení dĺžka, resetujeme časovač
      this.timeLeft = newValue;
      this.stopTimer();
    },
  },
};
</script>

<style scoped>
.timer {
  text-align: center;
}

.timer-display {
  font-size: 3em;
  color: #f1c40f;
}

.timer-controls button {
  padding: 10px 20px;
  font-size: 1.5em;
  margin: 10px;
  background-color: #f1c40f;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.timer-controls button:disabled {
  background-color: #777;
  cursor: not-allowed;
}
</style>
